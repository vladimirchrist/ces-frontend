export interface Administrador {
  id?: number
  nome: string
  username: string
  password: string
  enabled: boolean
}
