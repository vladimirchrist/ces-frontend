import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Title } from '@angular/platform-browser';
import { AdministradorService } from 'src/app/core/services/administrador.service';

export interface Administrador {
  position: number
  nome: string
  username: string
  ativo: string
}

@Component({
  selector: 'app-administrador-list',
  templateUrl: './administrador-list.component.html',
  styleUrls: ['./administrador-list.component.css']
})
export class AdministradorListComponent implements OnInit {

  administradores: any[]

  config = {
    nome: "",
    pagina: 0,
    itemsPorPagina: 20
  }

  displayedColumns: string[] = ['position', 'nome', 'username', 'ativo', 'acoes']
  dataSource = new MatTableDataSource<any>(this.administradores);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private administradorService: AdministradorService, private titleService: Title) { }

  ngOnInit(): void {
    this.titleService.setTitle('Administradores');
    this.dataSource.paginator = this.paginator;

    this.listarAdministradores()

  }

  listarAdministradores(): void {
    this.administradorService.getAdministradores(this.config).subscribe((administradores: any) => {
      this.administradores = administradores
      console.log(this.administradores)
      this.dataSource = new MatTableDataSource<any>(this.administradores)
      this.dataSource.paginator = this.paginator;
    })
  }

  resetarConsulta(): void {
    this.administradores = []
    this.listarAdministradores()
  }

  onDelete(id: number): void {
    this.administradorService.excluir(id);
  }

}
